# PoliEmergencias Medical Center

This is a single-page, static website for the PoliEmergencias Medical Center.

## How to use

Simply open the `index.html` file in your web browser. No installation or build steps are required.
