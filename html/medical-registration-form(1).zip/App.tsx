import React, { useState } from 'react';
import { ArrowLeft } from 'lucide-react';
import { InputField } from './components/InputField';
import { RegistrationFormData } from './types';

const App: React.FC = () => {
  const [formData, setFormData] = useState<RegistrationFormData>({
    nombre: '',
    contrasena: '',
    telefonoEmergencia: '',
    obraSocial: ''
  });

  const obrasSociales = [
    "Particular",
    "OSDE",
    "Swiss Medical",
    "Galeno",
    "Sancor Salud",
    "PAMI",
    "IOMA", 
    "Osecac",
    "Otra"
  ];

  // Handle standard inputs
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Form submitted:', formData);
    alert('Registro completado (simulación)');
  };

  return (
    <div className="flex min-h-screen w-full bg-white overflow-hidden">
      {/* Left Section - Form */}
      <div className="w-full lg:w-[50%] xl:w-[45%] flex flex-col justify-center px-8 sm:px-16 md:px-24 lg:px-16 xl:px-24 py-10 z-10 relative">
        
        {/* Header / Back Button */}
        <div className="mb-10">
          <button className="group flex items-center text-black text-3xl font-medium hover:text-gray-700 transition-colors">
            <ArrowLeft className="w-8 h-8 mr-2 group-hover:-translate-x-1 transition-transform" />
            Registro
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-x-6 gap-y-5">
            <InputField
              id="nombre"
              name="nombre"
              label="Nombre"
              placeholder="Nombre"
              value={formData.nombre}
              onChange={handleChange}
              required
            />
            <InputField
              id="contrasena"
              name="contrasena"
              label="Contraseña"
              placeholder="Contraseña"
              type="password"
              value={formData.contrasena}
              onChange={handleChange}
              required
            />
            <InputField
              id="telefonoEmergencia"
              name="telefonoEmergencia"
              label="Teléfono contacto de emergencia"
              placeholder="Teléfono de emergencia"
              type="tel"
              value={formData.telefonoEmergencia}
              onChange={handleChange}
              required
            />
            
            {/* Simple Select Tag */}
            <div className="flex flex-col space-y-1.5">
              <label htmlFor="obraSocial" className="text-sm font-medium text-gray-700 ml-1">
                Obra social
              </label>
              <select
                id="obraSocial"
                name="obraSocial"
                value={formData.obraSocial}
                onChange={handleChange}
                className="w-full px-4 py-2.5 border border-gray-300 rounded-full text-gray-700 bg-white focus:outline-none focus:ring-2 focus:ring-[#66a5ad] focus:border-transparent transition-all duration-200"
              >
                <option value="" disabled>Seleccionar...</option>
                {obrasSociales.map((opt) => (
                  <option key={opt} value={opt}>{opt}</option>
                ))}
              </select>
            </div>

          </div>

          {/* Footer Link */}
          <div className="pt-1">
            <p className="text-sm text-gray-600">
              Ya tengo cuenta <a href="#" className="text-blue-500 hover:underline font-medium">Iniciar sesión</a>
            </p>
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            className="w-full bg-[#66a5ad] hover:bg-[#538a91] text-white font-medium py-3 px-4 rounded-full shadow-md transition-colors duration-200 mt-4"
          >
            Continuar
          </button>
        </form>
      </div>

      {/* Right Section - Illustration */}
      <div className="hidden lg:flex w-[50%] xl:w-[55%] bg-[#bfdce3] relative items-center justify-center p-12 overflow-hidden">
        {/* Decorative Background Circles */}
        <div className="absolute top-10 right-20 w-32 h-32 bg-white/30 rounded-full blur-xl"></div>
        <div className="absolute bottom-20 left-20 w-64 h-64 bg-blue-200/40 rounded-full blur-2xl"></div>
        
        {/* Content Container */}
        <div className="relative z-10 max-w-2xl w-full flex flex-col items-center">
           <div className="relative w-full aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl bg-white/40 backdrop-blur-sm border border-white/50 p-4 flex items-center justify-center">
              <img 
                src="https://picsum.photos/800/600" 
                alt="Medical Illustration Placeholder" 
                className="rounded-xl w-full h-full object-cover opacity-90 mix-blend-overlay"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                  <div className="bg-white/90 p-8 rounded-2xl shadow-lg max-w-xs text-center">
                     <div className="w-16 h-16 bg-[#66a5ad] rounded-full mx-auto mb-4 flex items-center justify-center">
                        <svg className="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4" />
                        </svg>
                     </div>
                     <h3 className="text-[#66a5ad] font-bold text-lg">Gestión de Salud</h3>
                     <p className="text-gray-500 text-sm mt-2">Administra tus turnos y datos clínicos de manera segura.</p>
                  </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default App;