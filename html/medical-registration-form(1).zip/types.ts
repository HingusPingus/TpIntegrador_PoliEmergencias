import React from 'react';

export interface RegistrationFormData {
  nombre: string;
  contrasena: string;
  telefonoEmergencia: string;
  obraSocial: string;
}

export interface InputFieldProps extends React.InputHTMLAttributes<HTMLInputElement> {
  label: string;
  error?: string;
}